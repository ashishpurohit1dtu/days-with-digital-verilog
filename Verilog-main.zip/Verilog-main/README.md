## Verilog Coding
Each of the project contains implementation details of each design with RTL's and Test bench. You can refer to simulation, schematic diagrams(.png) and tcl consoles for your references.

Tool Used:

Xilinx Vivado v2024.1 (64-bit)
